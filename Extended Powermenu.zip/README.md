Mod to activate the second speaker (conversational). Version 3 - Improved sound quality, adjusted both speakers more evenly, added deep bass, in general it became really cool! Created only for Xiaomi Redmi Note 7

Attention! Please do not install this patch (module) on another phone, this patch is only for Xiaomi Redmi Note 7 - When installing on another phone, you are trying to get a brick!

## ChangeLog ##

Version 3

?!?!?